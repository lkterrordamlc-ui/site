import React from 'react';
import Navbar from '../components/landing/Navbar';
import HeroSection from '../components/landing/HeroSection';
import AboutSection from '../components/landing/AboutSection';
import FeaturesSection from '../components/landing/FeaturesSection';
import StatsSection from '../components/landing/StatsSection';
import RankingSection from '../components/landing/RankingSection';
import OwnersSection from '../components/landing/OwnersSection';
import CommunitySection from '../components/landing/CommunitySection';
import FactionsSection from '../components/landing/FactionsSection';
import HowToPlay from '../components/landing/HowToPlay';
import EventsSection from '../components/landing/EventsSection';
import FloatingParticles from '../components/landing/FloatingParticles';
import Footer from '../components/landing/Footer';

const HERO_IMG = 'https://media.base44.com/images/public/6a054c2e34afcefbab9eb2da/00c1e7a33_generated_314c4085.png';
const ABOUT_IMG = 'https://media.base44.com/images/public/6a054c2e34afcefbab9eb2da/7fd5533dc_generated_dc82654f.png';
const FEATURES_IMG = 'https://media.base44.com/images/public/6a054c2e34afcefbab9eb2da/6efb53ba4_generated_de108500.png';
const FAVELA_IMG = 'https://media.base44.com/images/public/6a054c2e34afcefbab9eb2da/c602a9467_generated_image.png';

export default function Home() {
  return (
    <div className="min-h-screen bg-background relative">
      <FloatingParticles />
      <div className="relative z-10">
        <Navbar />
        <HeroSection heroImage={HERO_IMG} />
        <StatsSection />
        <CommunitySection favelaBg={FAVELA_IMG} />
        <AboutSection aboutImage={ABOUT_IMG} />
        <FeaturesSection featuresImage={FEATURES_IMG} />
        <FactionsSection factionsBg={FAVELA_IMG} />
        <EventsSection />
        <HowToPlay />
        <OwnersSection favelaBg={FAVELA_IMG} />
        <RankingSection />
        <Footer />
      </div>
    </div>
  );
}