import React from 'react';
import { motion } from 'framer-motion';
import { Crosshair, Users, Shield, Flame } from 'lucide-react';

const highlights = [
  { icon: Crosshair, label: 'COMBATE', desc: 'Sistema de combate intenso e dinâmico' },
  { icon: Users, label: 'COMUNIDADE', desc: 'Milhares de jogadores online diariamente' },
  { icon: Shield, label: 'ANTI-CHEAT', desc: 'Proteção avançada contra hackers' },
  { icon: Flame, label: 'EVENTOS', desc: 'Eventos exclusivos toda semana' },
];

export default function AboutSection({ aboutImage }) {
  return (
    <section id="about" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img src={aboutImage} alt="New Rio streets" className="w-full h-full object-cover opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          {/* Text */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-xs font-bold tracking-widest text-primary mb-4 block">SOBRE O SERVIDOR</span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-foreground leading-tight mb-6">
              BEM-VINDO À<br />
              <span className="text-primary">NEW RIO</span>
            </h2>
            <div className="space-y-4 text-muted-foreground text-sm leading-relaxed">
              <p>
                New Rio é o servidor de GTA San Andreas Multiplayer (SA-MP) que redefine a experiência de roleplay 
                no Brasil. Nossas ruas são vivas, nossas gangues são implacáveis e nossa comunidade é incomparável.
              </p>
              <p>
                Com sistemas exclusivos de economia, propriedades, veículos e facções, cada jogador constrói 
                sua própria história nesta metrópole digital. Das favelas aos arranha-céus, cada esquina 
                conta uma história diferente.
              </p>
            </div>

            {/* Velocity Line */}
            <div className="my-8 flex items-center gap-2">
              <div className="h-px flex-1 bg-gradient-to-r from-primary to-transparent" />
              <div className="w-2 h-2 rotate-45 bg-primary" />
            </div>

            {/* Highlights grid */}
            <div className="grid grid-cols-2 gap-4">
              {highlights.map(({ icon: Icon, label, desc }) => (
                <div key={label} className="p-4 rounded-lg bg-card/50 border border-border hover:border-primary/30 transition-colors">
                  <Icon className="w-5 h-5 text-primary mb-2" />
                  <p className="text-xs font-bold tracking-widest text-foreground mb-1">{label}</p>
                  <p className="text-xs text-muted-foreground">{desc}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="rounded-xl overflow-hidden border border-border shadow-2xl shadow-primary/5">
              <img src={aboutImage} alt="New Rio community" className="w-full h-auto" />
            </div>
            {/* Decorative accent */}
            <div className="absolute -bottom-4 -right-4 w-24 h-24 border-2 border-primary/20 rounded-xl -z-10" />
            <div className="absolute -top-4 -left-4 w-16 h-16 border-2 border-accent/20 rounded-xl -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}