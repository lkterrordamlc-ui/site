import React, { useState } from 'react';
import { motion, useMotionValue, useTransform, useSpring } from 'framer-motion';
import { Crown, Shield, Zap, Star, ChevronRight } from 'lucide-react';

const owners = [
  {
    id: 'semcleo',
    name: 'SEMCLEO',
    role: 'CO-FUNDADOR & ADM CHEFE',
    image: 'https://media.base44.com/images/public/6a054c2e34afcefbab9eb2da/23c9bf0ef_generated_image.png',
    color: '#2D5BFF',
    badge: Crown,
    bio: 'Das vielas do Rio para os servidores do Brasil. Semcleo construiu o New Rio do zero, com a mão calejada e a mente afiada. Conhece cada beco, cada facção, cada jogador pelo nome. Sua palavra é lei nas ruas digitais.',
    stats: [
      { label: 'ANOS ONLINE', value: '6+' },
      { label: 'HORAS JOGADAS', value: '12K' },
      { label: 'EVENTOS CRIADOS', value: '340+' },
    ],
    quote: '"Quem não nasceu na luta, não sabe o que é vencer."',
    tags: ['FUNDADOR', 'ROLEPLAY', 'ECONOMIA'],
  },
  {
    id: 'menog',
    name: 'MENOG',
    role: 'CO-FUNDADOR & DIRETOR TÉCNICO',
    image: 'https://media.base44.com/images/public/6a054c2e34afcefbab9eb2da/a725d0c15_generated_image.png',
    color: '#FFB800',
    badge: Shield,
    bio: 'O arquiteto por trás do caos organizado. Menog é o gênio técnico que transforma ideias em sistemas, bugs em features e servidores em metrópoles. Se o New Rio funciona, é porque ele não dorme.',
    stats: [
      { label: 'SCRIPTS CRIADOS', value: '500+' },
      { label: 'BUGS RESOLVIDOS', value: '2K+' },
      { label: 'UPTIME', value: '99.9%' },
    ],
    quote: '"O código é a favela — todo mundo tem seu lugar."',
    tags: ['SCRIPTING', 'ANTI-CHEAT', 'SISTEMAS'],
  },
];

function OwnerCard({ owner }) {
  const [hovered, setHovered] = useState(false);
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const rotateX = useSpring(useTransform(mouseY, [0, 1], [8, -8]), { stiffness: 200, damping: 20 });
  const rotateY = useSpring(useTransform(mouseX, [0, 1], [-8, 8]), { stiffness: 200, damping: 20 });

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    mouseX.set((e.clientX - rect.left) / rect.width);
    mouseY.set((e.clientY - rect.top) / rect.height);
  };
  const handleMouseLeave = () => {
    mouseX.set(0.5);
    mouseY.set(0.5);
    setHovered(false);
  };

  const BadgeIcon = owner.badge;

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.7 }}
      style={{ perspective: 1000 }}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={handleMouseLeave}
      className="group cursor-default"
    >
      <motion.div
        style={{ rotateX, rotateY }}
        className="relative rounded-2xl border border-border overflow-hidden bg-card/60 backdrop-blur-md"
      >
        {/* Animated border glow */}
        <motion.div
          animate={{ opacity: hovered ? 1 : 0 }}
          transition={{ duration: 0.4 }}
          className="absolute inset-0 rounded-2xl pointer-events-none z-20"
          style={{
            boxShadow: `inset 0 0 40px 0 ${owner.color}22, 0 0 40px 0 ${owner.color}15`,
          }}
        />

        {/* Image area */}
        <div className="relative h-72 sm:h-80 overflow-hidden">
          <motion.img
            src={owner.image}
            alt={owner.name}
            animate={{ scale: hovered ? 1.07 : 1 }}
            transition={{ duration: 0.6 }}
            className="w-full h-full object-cover object-top"
          />
          {/* Gradient over image */}
          <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />

          {/* Role badge top-right */}
          <div className="absolute top-4 right-4 flex items-center gap-1.5 px-3 py-1.5 rounded-full backdrop-blur-md border border-white/10 bg-black/40">
            <BadgeIcon className="w-3 h-3" style={{ color: owner.color }} />
            <span className="text-[9px] font-extrabold tracking-widest text-white">DONO</span>
          </div>

          {/* Scanline overlay */}
          <div className="absolute inset-0 pointer-events-none opacity-10" style={{
            backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(255,255,255,0.05) 3px, rgba(255,255,255,0.05) 4px)',
          }} />
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Name */}
          <div className="mb-3">
            <p className="text-[10px] font-bold tracking-widest mb-1" style={{ color: owner.color }}>
              {owner.role}
            </p>
            <h3 className="text-2xl font-black tracking-tighter text-foreground">{owner.name}</h3>
          </div>

          {/* Quote */}
          <div className="relative mb-4 pl-3 py-1 border-l-2" style={{ borderColor: owner.color }}>
            <p className="text-xs italic text-muted-foreground leading-relaxed">{owner.quote}</p>
          </div>

          {/* Bio */}
          <p className="text-xs text-muted-foreground leading-relaxed mb-5">{owner.bio}</p>

          {/* Stats row */}
          <div className="grid grid-cols-3 gap-2 mb-5">
            {owner.stats.map(({ label, value }) => (
              <div key={label} className="text-center p-2 rounded-lg bg-background/50 border border-border">
                <p className="text-sm font-black text-foreground">{value}</p>
                <p className="text-[8px] font-bold tracking-widest text-muted-foreground mt-0.5">{label}</p>
              </div>
            ))}
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2">
            {owner.tags.map(tag => (
              <span
                key={tag}
                className="px-2.5 py-1 rounded-md text-[9px] font-extrabold tracking-widest border"
                style={{
                  color: owner.color,
                  borderColor: `${owner.color}40`,
                  backgroundColor: `${owner.color}10`,
                }}
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Bottom accent line */}
        <motion.div
          animate={{ scaleX: hovered ? 1 : 0 }}
          transition={{ duration: 0.4 }}
          className="absolute bottom-0 left-0 right-0 h-0.5 origin-left"
          style={{ background: `linear-gradient(to right, ${owner.color}, transparent)` }}
        />
      </motion.div>
    </motion.div>
  );
}

export default function OwnersSection({ favelaBg }) {
  return (
    <section id="owners" className="relative py-24 md:py-36 overflow-hidden">
      {/* Favela Background */}
      <div className="absolute inset-0">
        <img src={favelaBg} alt="Favela" className="w-full h-full object-cover opacity-15" />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/90 to-background" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/60 via-transparent to-background/60" />
      </div>

      {/* Topographic line pattern */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.04]" style={{
        backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 24px, hsl(227 100% 59%) 24px, hsl(227 100% 59%) 25px)`,
      }} />

      <div className="relative z-10 max-w-6xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-xs font-bold tracking-widest text-primary mb-4 block">A LIDERANÇA</span>
          <h2 className="text-3xl sm:text-5xl font-black tracking-tight text-foreground">
            OS <span className="text-primary">DONOS</span> DAS RUAS
          </h2>
          <div className="mt-6 flex items-center justify-center gap-3">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-primary" />
            <Star className="w-3 h-3 text-accent" />
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-primary" />
          </div>
          <p className="mt-5 text-sm text-muted-foreground max-w-xl mx-auto leading-relaxed">
            Nascidos nas comunidades do Rio, criaram o New Rio com sangue, suor e paixão pelo jogo.
            Dois guerreiros. Um servidor. Uma missão.
          </p>
        </motion.div>

        {/* Cards */}
        <div className="grid md:grid-cols-2 gap-8">
          {owners.map(owner => (
            <OwnerCard key={owner.id} owner={owner} />
          ))}
        </div>

        {/* Bottom manifesto */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="mt-16 relative rounded-2xl overflow-hidden border border-primary/20 p-8 text-center"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-card/80 to-accent/5" />
          <div className="relative z-10">
            <Zap className="w-6 h-6 text-primary mx-auto mb-4" />
            <h3 className="text-xl sm:text-2xl font-black tracking-tight text-foreground mb-3">
              "O NEW RIO NÃO É SÓ UM SERVIDOR.<br className="hidden sm:block" />
              <span className="text-primary"> É UMA REALIDADE."</span>
            </h3>
            <p className="text-xs text-muted-foreground tracking-widest">— SEMCLEO & MENOG, FUNDADORES</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}