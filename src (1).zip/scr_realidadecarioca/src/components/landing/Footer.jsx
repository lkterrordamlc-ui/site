import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Zap, MessageSquare, ExternalLink, BookOpen, FileText, Users, ChevronRight, Mail } from 'lucide-react';

const navLinks = [
  { label: 'Início', href: '#hero' },
  { label: 'Sobre', href: '#about' },
  { label: 'Facções', href: '#factions' },
  { label: 'Como Jogar', href: '#howtoplay' },
  { label: 'Eventos', href: '#events' },
  { label: 'Ranking', href: '#ranking' },
  { label: 'Os Donos', href: '#owners' },
];

const socials = [
  { label: 'Discord', icon: MessageSquare, href: '#', color: '#5865F2' },
  { label: 'Fórum', icon: BookOpen, href: '#', color: '#2D5BFF' },
  { label: 'Regras', icon: FileText, href: '#', color: '#FFB800' },
  { label: 'Recrutar', icon: Users, href: '#', color: '#FF3E3E' },
];

const SERVER_IP = 'play.newrio.com:7777';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);

  const handleNewsletter = (e) => {
    e.preventDefault();
    if (!email) return;
    setSent(true);
    setEmail('');
    setTimeout(() => setSent(false), 3000);
  };

  return (
    <footer className="relative border-t border-border bg-card/20 overflow-hidden">
      {/* Top grid pattern */}
      <div className="absolute inset-0 opacity-[0.025]" style={{
        backgroundImage: 'linear-gradient(hsl(227 100% 59%) 1px, transparent 1px), linear-gradient(to right, hsl(227 100% 59%) 1px, transparent 1px)',
        backgroundSize: '60px 60px',
      }} />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
                <Zap className="w-4.5 h-4.5 text-primary-foreground" />
              </div>
              <span className="text-lg font-extrabold tracking-wider text-foreground">
                NEW <span className="text-primary">RIO</span>
              </span>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed mb-5">
              O servidor de GTA SA-MP mais imersivo do Brasil. Cultura carioca, roleplay intenso e comunidade única.
            </p>
            <div className="font-mono text-xs text-primary tracking-wider px-3 py-2 rounded-lg border border-primary/20 bg-primary/5 inline-block">
              {SERVER_IP}
            </div>
          </div>

          {/* Navigation */}
          <div>
            <p className="text-[10px] font-extrabold tracking-widest text-muted-foreground mb-5">NAVEGAÇÃO</p>
            <ul className="space-y-2.5">
              {navLinks.map(l => (
                <li key={l.label}>
                  <a
                    href={l.href}
                    className="group flex items-center gap-2 text-xs text-muted-foreground hover:text-primary transition-colors duration-200"
                  >
                    <ChevronRight className="w-3 h-3 opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all duration-200 text-primary" />
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Social */}
          <div>
            <p className="text-[10px] font-extrabold tracking-widest text-muted-foreground mb-5">COMUNIDADE</p>
            <div className="space-y-3">
              {socials.map(({ label, icon: Icon, href, color }) => (
                <motion.a
                  key={label}
                  href={href}
                  whileHover={{ x: 4 }}
                  className="flex items-center gap-3 group"
                >
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center transition-all duration-300 group-hover:scale-110"
                    style={{ backgroundColor: `${color}20` }}>
                    <Icon className="w-3.5 h-3.5" style={{ color }} />
                  </div>
                  <span className="text-xs text-muted-foreground group-hover:text-foreground transition-colors duration-200 font-medium">
                    {label}
                  </span>
                  <ExternalLink className="w-2.5 h-2.5 text-muted-foreground/40 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Newsletter */}
          <div>
            <p className="text-[10px] font-extrabold tracking-widest text-muted-foreground mb-5">AVISOS & EVENTOS</p>
            <p className="text-xs text-muted-foreground leading-relaxed mb-4">
              Receba notificações de eventos, atualizações e novidades do servidor.
            </p>
            <form onSubmit={handleNewsletter} className="space-y-3">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                  className="w-full pl-9 pr-4 py-2.5 rounded-lg bg-card border border-border text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 transition-colors"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 rounded-lg bg-primary hover:bg-primary/80 text-primary-foreground text-xs font-extrabold tracking-wider transition-all duration-300 hover:scale-[1.02]"
              >
                {sent ? '✓ INSCRITO!' : 'INSCREVER-SE'}
              </button>
            </form>
          </div>
        </div>

        {/* Divider + bottom */}
        <div className="border-t border-border pt-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-[10px] text-muted-foreground tracking-wider text-center sm:text-left">
              © 2026 NEW RIO SAMP — FUNDADO POR <span className="text-primary font-bold">SEMCLEO</span> &amp; <span className="text-accent font-bold">MENOG</span>
            </p>
            <div className="flex items-center gap-4">
              <span className="text-[9px] font-bold tracking-[0.3em] text-muted-foreground/40">SA-MP 0.3.7</span>
              <div className="w-px h-3 bg-border" />
              <span className="text-[9px] font-bold tracking-[0.3em] text-muted-foreground/40">GTA:SA</span>
              <div className="w-px h-3 bg-border" />
              <span className="text-[9px] font-bold tracking-[0.3em] text-muted-foreground/40">BRASIL</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}