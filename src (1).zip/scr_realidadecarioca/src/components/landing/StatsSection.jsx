import React from 'react';
import { motion } from 'framer-motion';

const stats = [
  { value: '10K+', label: 'JOGADORES REGISTRADOS' },
  { value: '500', label: 'SLOTS ONLINE' },
  { value: '200+', label: 'VEÍCULOS ÚNICOS' },
  { value: '24/7', label: 'SERVIDOR ATIVO' },
];

export default function StatsSection() {
  return (
    <section id="stats" className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-card/50" />
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 40px, hsl(227 100% 59%) 40px, hsl(227 100% 59%) 41px)',
      }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map(({ value, label }, i) => (
            <motion.div
              key={label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ scale: 1.07 }}
              className="text-center cursor-default group"
            >
              <p className="text-3xl sm:text-4xl md:text-5xl font-black text-foreground tracking-tighter group-hover:text-primary transition-colors duration-300">
                {value}
              </p>
              <div className="mt-2 h-px w-12 mx-auto bg-gradient-to-r from-transparent via-primary to-transparent group-hover:w-20 transition-all duration-300" />
              <p className="mt-3 text-[10px] sm:text-xs font-bold tracking-widest text-muted-foreground">
                {label}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}