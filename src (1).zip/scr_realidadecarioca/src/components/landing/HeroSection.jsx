import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Copy, CheckCheck, Radio } from 'lucide-react';
import { motion, useMotionValue, useTransform } from 'framer-motion';

const SERVER_IP = 'play.newrio.com:7777';

export default function HeroSection({ heroImage }) {
  const [copied, setCopied] = useState(false);
  const [ripples, setRipples] = useState([]);
  const [playerCount, setPlayerCount] = useState(482);

  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const rotateX = useTransform(mouseY, [0, 1], [3, -3]);
  const rotateY = useTransform(mouseX, [0, 1], [-3, 3]);

  // Simulate live player count
  useEffect(() => {
    const interval = setInterval(() => {
      setPlayerCount(prev => {
        const delta = Math.random() > 0.5 ? 1 : -1;
        return Math.min(500, Math.max(450, prev + delta));
      });
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    mouseX.set((e.clientX - rect.left) / rect.width);
    mouseY.set((e.clientY - rect.top) / rect.height);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(SERVER_IP);
    setCopied(true);
    const id = Date.now();
    setRipples(r => [...r, id]);
    setTimeout(() => setCopied(false), 2000);
    setTimeout(() => setRipples(r => r.filter(x => x !== id)), 1200);
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      onMouseMove={handleMouseMove}
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="New Rio cityscape"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/50 to-background" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-transparent to-background/60" />
      </div>

      {/* Floating particle dots */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 rounded-full bg-primary/40"
          style={{
            left: `${10 + i * 7.5}%`,
            top: `${20 + (i % 5) * 15}%`,
          }}
          animate={{
            y: [0, -20, 0],
            opacity: [0.2, 0.7, 0.2],
          }}
          transition={{
            duration: 3 + (i % 3),
            delay: i * 0.4,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
      ))}

      {/* Ripple Effects */}
      {ripples.map(id => (
        <motion.div
          key={id}
          initial={{ scale: 0, opacity: 0.8 }}
          animate={{ scale: 12, opacity: 0 }}
          transition={{ duration: 1.2, ease: 'easeOut' }}
          className="absolute w-24 h-24 rounded-full border-2 border-primary z-30 pointer-events-none"
          style={{ left: '50%', top: '50%', translate: '-50% -50%' }}
        />
      ))}

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        {/* Server Status */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card/60 backdrop-blur-md border border-border mb-8 hover:border-primary/40 transition-colors duration-300"
        >
          <Radio className="w-3 h-3 text-green-500 animate-pulse" />
          <span className="text-xs font-semibold tracking-widest text-green-400">SERVIDOR ONLINE</span>
          <span className="text-xs text-muted-foreground">|</span>
          <motion.span
            key={playerCount}
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-xs font-bold text-foreground tracking-wider"
          >
            {playerCount}/500 JOGADORES
          </motion.span>
        </motion.div>

        {/* 3D Tilt Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          style={{ rotateX, rotateY, perspective: 800 }}
        >
          <h1 className="text-5xl sm:text-7xl md:text-8xl font-black tracking-tighter leading-none mb-4 select-none">
            <span className="text-foreground drop-shadow-2xl">NEW</span>
            <br />
            <span
              className="text-primary"
              style={{ textShadow: '0 0 60px rgba(45,91,255,0.6)' }}
            >
              RIO
            </span>
          </h1>
        </motion.div>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-muted-foreground text-sm sm:text-base font-medium tracking-wide max-w-xl mx-auto mb-10"
        >
          O servidor de GTA San Andreas Multiplayer mais intenso do Brasil.
          <br className="hidden sm:block" />
          Entre na rebelião. Domine as ruas. Construa seu império.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <motion.div whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.97 }}>
            <Button
              size="lg"
              onClick={handleCopy}
              className="relative bg-primary hover:bg-primary/90 text-primary-foreground font-extrabold tracking-wider text-sm px-10 py-6 rounded-lg overflow-hidden group"
            >
              {/* Shimmer sweep */}
              <motion.span
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12"
                initial={{ x: '-100%' }}
                whileHover={{ x: '200%' }}
                transition={{ duration: 0.6 }}
              />
              <span className="relative z-10 flex items-center gap-2">
                {copied ? <CheckCheck className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                {copied ? 'IP COPIADO!' : 'COPIAR IP & JOGAR'}
              </span>
            </Button>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.04, borderColor: 'rgba(45,91,255,0.5)' }}
            className="text-xs text-muted-foreground font-mono tracking-wider px-5 py-3 rounded-lg border border-border bg-card/40 backdrop-blur-sm cursor-pointer hover:text-foreground transition-colors duration-300"
            onClick={handleCopy}
          >
            {SERVER_IP}
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="w-5 h-8 rounded-full border-2 border-muted-foreground/30 flex items-start justify-center p-1"
          >
            <div className="w-1 h-2 rounded-full bg-primary" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}