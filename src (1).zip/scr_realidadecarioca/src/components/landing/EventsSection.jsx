import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Trophy, Zap, Clock } from 'lucide-react';

const events = [
  {
    title: 'GUERRA DE FACÇÕES',
    date: 'TODO SÁBADO — 21H',
    prize: 'R$ 500.000 in-game',
    desc: 'As facções se enfrentam em batalha campal pelo controle do mapa. A mais sanguinária da semana.',
    color: '#FF3E3E',
    icon: Zap,
    live: true,
  },
  {
    title: 'CORRIDA NOTURNA',
    date: 'SEXTAS — 22H',
    prize: 'Veículo exclusivo',
    desc: 'Circuito pelas ruas do New Rio com veículos tunados. Velocidade e adrenalina pura.',
    color: '#FFB800',
    icon: Trophy,
    live: false,
  },
  {
    title: 'OPERAÇÃO POLICIAL',
    date: 'DOMINGOS — 20H',
    prize: 'Rank especial + XP',
    desc: 'Policiais vs Criminosos em missão de alta complexidade. Estratégia, trabalho em equipe e sangue frio.',
    color: '#2D5BFF',
    icon: Calendar,
    live: false,
  },
];

export default function EventsSection() {
  return (
    <section id="events" className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-card/30 via-background to-background" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <span className="text-xs font-bold tracking-widest text-accent mb-4 block">AGENDA</span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-foreground">
            EVENTOS <span className="text-primary">SEMANAIS</span>
          </h2>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {events.map(({ title, date, prize, desc, color, icon: Icon, live }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.12 }}
              whileHover={{ y: -6, scale: 1.02 }}
              className="group relative rounded-2xl border bg-card/60 backdrop-blur-sm overflow-hidden cursor-default transition-colors duration-300"
              style={{ borderColor: `${color}30` }}
            >
              {/* Top gradient bar */}
              <div className="h-1" style={{ background: `linear-gradient(to right, ${color}, transparent)` }} />

              {/* Hover glow */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                style={{ background: `radial-gradient(circle at 50% 0%, ${color}12, transparent 70%)` }}
              />

              <div className="relative z-10 p-6">
                {/* Live badge */}
                {live && (
                  <div className="flex items-center gap-1.5 mb-3">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                    <span className="text-[9px] font-extrabold tracking-widest text-red-400">AO VIVO AGORA</span>
                  </div>
                )}

                <div className="flex items-start gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${color}20` }}>
                    <Icon className="w-5 h-5" style={{ color }} />
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold tracking-wider text-foreground leading-tight">{title}</h3>
                    <div className="flex items-center gap-1 mt-1">
                      <Clock className="w-3 h-3 text-muted-foreground" />
                      <span className="text-[9px] text-muted-foreground tracking-wider">{date}</span>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-muted-foreground leading-relaxed mb-4">{desc}</p>

                <div className="flex items-center justify-between pt-3 border-t border-border">
                  <span className="text-[9px] font-bold tracking-widest text-muted-foreground">PRÊMIO</span>
                  <span className="text-xs font-extrabold" style={{ color }}>{prize}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}