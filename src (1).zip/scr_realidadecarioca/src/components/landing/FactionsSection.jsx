import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Swords, Shield, AlertTriangle, Star, Users, MapPin, ChevronRight } from 'lucide-react';

const factions = [
  {
    id: 'cartel',
    name: 'LOS SANTOS CARTEL',
    type: 'CRIME ORGANIZADO',
    color: '#FF3E3E',
    members: 87,
    territory: 'Complexo do Alemão',
    power: 95,
    icon: Swords,
    desc: 'A facção mais temida do servidor. Controlam o tráfico, as apostas e os contratos de morte. Entrar é fácil. Sair é impossível.',
    perks: ['Acesso a armas pesadas', 'Renda passiva de territórios', 'Missões exclusivas de alto risco'],
    color2: '#8B0000',
  },
  {
    id: 'policia',
    name: 'POLÍCIA CIVIL',
    type: 'FORÇA DA LEI',
    color: '#2D5BFF',
    members: 64,
    territory: 'Cidade Alta',
    power: 80,
    icon: Shield,
    desc: 'Os guardiões da ordem (ou nem tanto). Caçam criminosos, investigam casos e às vezes cruzam a linha entre lei e crime.',
    perks: ['Acesso a viaturas exclusivas', 'Sistema de investigação', 'Mandados e prisões'],
    color2: '#003399',
  },
  {
    id: 'vagos',
    name: 'OS VAGOS',
    type: 'GANGUE DE RUA',
    color: '#FFB800',
    members: 112,
    territory: 'Favela do Lixão',
    power: 72,
    icon: AlertTriangle,
    desc: 'Nascidos nas ruas, morrerão nas ruas. Os Vagos são a gangue mais numerosa do New Rio, com lealdade inabalável ao bairro.',
    perks: ['Maior gangue do servidor', 'Roubos e sequestros', 'Controle de becos e vielas'],
    color2: '#8B6914',
  },
  {
    id: 'mafia',
    name: 'MÁFIA ITALIANA',
    type: 'CRIME DE ELITE',
    color: '#A0A0A0',
    members: 38,
    territory: 'Barra da Tijuca',
    power: 88,
    icon: Star,
    desc: 'Operando nas sombras da alta sociedade. A Máfia controla cassinos, lavagem de dinheiro e os negócios mais lucrativos do servidor.',
    perks: ['Acesso a negócios luxuosos', 'Rede de informantes', 'Contratos corporativos ilegais'],
    color2: '#404040',
  },
];

function FactionCard({ faction, isActive, onClick }) {
  const Icon = faction.icon;
  return (
    <motion.div
      onClick={onClick}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className="relative p-5 rounded-xl border cursor-pointer transition-all duration-300 overflow-hidden"
      style={{
        borderColor: isActive ? `${faction.color}60` : 'hsl(228 20% 15%)',
        backgroundColor: isActive ? `${faction.color}10` : 'hsl(228 25% 7% / 0.6)',
      }}
    >
      {isActive && (
        <motion.div
          layoutId="faction-glow"
          className="absolute inset-0 rounded-xl"
          style={{ boxShadow: `inset 0 0 30px ${faction.color}20` }}
        />
      )}
      <div className="relative z-10 flex items-center gap-4">
        <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
          style={{ backgroundColor: `${faction.color}20` }}>
          <Icon className="w-5 h-5" style={{ color: faction.color }} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-extrabold tracking-wider text-foreground truncate">{faction.name}</p>
          <p className="text-[9px] tracking-widest mt-0.5" style={{ color: faction.color }}>{faction.type}</p>
        </div>
        <ChevronRight className={`w-4 h-4 flex-shrink-0 transition-all duration-300 ${isActive ? 'rotate-90' : ''}`}
          style={{ color: isActive ? faction.color : 'hsl(228 10% 55%)' }} />
      </div>

      {/* Power bar */}
      <div className="mt-3 h-1 rounded-full bg-border overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          whileInView={{ width: `${faction.power}%` }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.2 }}
          className="h-full rounded-full"
          style={{ backgroundColor: faction.color }}
        />
      </div>
      <div className="flex justify-between mt-1">
        <span className="text-[8px] text-muted-foreground tracking-widest">PODER</span>
        <span className="text-[8px] font-bold" style={{ color: faction.color }}>{faction.power}%</span>
      </div>
    </motion.div>
  );
}

export default function FactionsSection({ factionsBg }) {
  const [active, setActive] = useState(0);
  const faction = factions[active];
  const Icon = faction.icon;

  return (
    <section id="factions" className="relative py-24 md:py-32 overflow-hidden">
      {/* BG */}
      <div className="absolute inset-0">
        {factionsBg && <img src={factionsBg} alt="" className="w-full h-full object-cover opacity-15" />}
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/90 to-background" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <span className="text-xs font-bold tracking-widest text-destructive mb-4 block">FACÇÕES</span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-foreground">
            ESCOLHA SEU <span className="text-primary">LADO</span>
          </h2>
          <div className="mt-6 flex items-center justify-center gap-3">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-destructive" />
            <div className="w-2 h-2 rotate-45 bg-destructive" />
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-destructive" />
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 items-start">
          {/* List */}
          <div className="space-y-3">
            {factions.map((f, i) => (
              <motion.div
                key={f.id}
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <FactionCard faction={f} isActive={active === i} onClick={() => setActive(i)} />
              </motion.div>
            ))}
          </div>

          {/* Detail Panel */}
          <AnimatePresence mode="wait">
            <motion.div
              key={active}
              initial={{ opacity: 0, x: 30, scale: 0.97 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: -30, scale: 0.97 }}
              transition={{ duration: 0.35 }}
              className="sticky top-24 rounded-2xl border overflow-hidden"
              style={{ borderColor: `${faction.color}40`, backgroundColor: 'hsl(228 25% 7% / 0.8)' }}
            >
              {/* Color band */}
              <div className="h-1.5 w-full" style={{
                background: `linear-gradient(to right, ${faction.color}, ${faction.color2})`
              }} />

              <div className="p-7">
                {/* Title */}
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${faction.color}20` }}>
                    <Icon className="w-7 h-7" style={{ color: faction.color }} />
                  </div>
                  <div>
                    <p className="text-[9px] font-bold tracking-widest mb-1" style={{ color: faction.color }}>{faction.type}</p>
                    <h3 className="text-xl font-black tracking-tight text-foreground">{faction.name}</h3>
                  </div>
                </div>

                {/* Stats row */}
                <div className="grid grid-cols-2 gap-3 mb-6">
                  <div className="p-3 rounded-lg bg-background/50 border border-border text-center">
                    <p className="text-lg font-black text-foreground">{faction.members}</p>
                    <p className="text-[9px] tracking-widest text-muted-foreground mt-0.5">MEMBROS ATIVOS</p>
                  </div>
                  <div className="p-3 rounded-lg bg-background/50 border border-border text-center">
                    <p className="text-lg font-black text-foreground">{faction.power}%</p>
                    <p className="text-[9px] tracking-widest text-muted-foreground mt-0.5">NÍVEL DE PODER</p>
                  </div>
                </div>

                {/* Territory */}
                <div className="flex items-center gap-2 mb-5 p-3 rounded-lg bg-background/30 border border-border">
                  <MapPin className="w-4 h-4 flex-shrink-0" style={{ color: faction.color }} />
                  <div>
                    <p className="text-[9px] tracking-widest text-muted-foreground">TERRITÓRIO PRINCIPAL</p>
                    <p className="text-xs font-bold text-foreground">{faction.territory}</p>
                  </div>
                </div>

                {/* Desc */}
                <p className="text-sm text-muted-foreground leading-relaxed mb-6">{faction.desc}</p>

                {/* Perks */}
                <div className="space-y-2">
                  <p className="text-[9px] font-bold tracking-widest text-muted-foreground mb-3">BENEFÍCIOS EXCLUSIVOS</p>
                  {faction.perks.map(perk => (
                    <div key={perk} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: faction.color }} />
                      <p className="text-xs text-muted-foreground">{perk}</p>
                    </div>
                  ))}
                </div>

                {/* CTA */}
                <button
                  onClick={() => navigator.clipboard.writeText('play.newrio.com:7777')}
                  className="mt-6 w-full py-3 rounded-xl text-xs font-extrabold tracking-widest transition-all duration-300 hover:scale-[1.02]"
                  style={{
                    background: `linear-gradient(to right, ${faction.color}, ${faction.color2})`,
                    color: '#fff',
                  }}
                >
                  ENTRAR COMO {faction.name.split(' ')[0]}
                </button>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}