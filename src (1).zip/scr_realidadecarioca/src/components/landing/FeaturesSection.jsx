import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Car, Home, Swords, Banknote, MapPin, Trophy } from 'lucide-react';

const features = [
  {
    icon: Car,
    title: 'VEÍCULOS EXCLUSIVOS',
    desc: 'Mais de 200 veículos customizáveis com sistema de tunning completo, corridas e perseguições.',
  },
  {
    icon: Home,
    title: 'PROPRIEDADES',
    desc: 'Compre casas, apartamentos e negócios. Construa seu império imobiliário pela cidade.',
  },
  {
    icon: Swords,
    title: 'SISTEMA DE FACÇÕES',
    desc: 'Crie ou entre em gangues, domine territórios e declare guerra contra facções rivais.',
  },
  {
    icon: Banknote,
    title: 'ECONOMIA REAL',
    desc: 'Trabalhe, negocie e invista. Sistema econômico dinâmico com empregos e negócios.',
  },
  {
    icon: MapPin,
    title: 'MAPA EXPANDIDO',
    desc: 'Explore áreas exclusivas inspiradas no Rio de Janeiro com missões únicas.',
  },
  {
    icon: Trophy,
    title: 'RANKING & EVENTOS',
    desc: 'Compita em eventos semanais, suba no ranking e ganhe recompensas exclusivas.',
  },
];

function FeatureCard({ icon: Icon, title, desc, i }) {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [hovered, setHovered] = useState(false);

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: i * 0.1 }}
      whileHover={{ y: -6, scale: 1.02 }}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="group relative p-6 rounded-xl bg-card/60 backdrop-blur-sm border border-border hover:border-primary/50 transition-colors duration-300 cursor-default overflow-hidden"
    >
      {/* Mouse-tracking radial glow */}
      {hovered && (
        <div
          className="absolute inset-0 rounded-xl pointer-events-none transition-opacity duration-300"
          style={{
            background: `radial-gradient(circle at ${mousePos.x}% ${mousePos.y}%, rgba(45,91,255,0.12) 0%, transparent 70%)`,
          }}
        />
      )}

      {/* Top glow line */}
      <motion.div
        initial={{ scaleX: 0 }}
        whileHover={{ scaleX: 1 }}
        transition={{ duration: 0.3 }}
        className="absolute top-0 left-6 right-6 h-px bg-gradient-to-r from-transparent via-primary to-transparent origin-left"
      />

      <div className="relative z-10">
        <motion.div
          whileHover={{ rotate: 10, scale: 1.15 }}
          transition={{ type: 'spring', stiffness: 300 }}
          className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center mb-4"
        >
          <Icon className="w-5 h-5 text-primary" />
        </motion.div>
        <h3 className="text-sm font-extrabold tracking-wider text-foreground mb-2 group-hover:text-primary transition-colors duration-300">{title}</h3>
        <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
      </div>

      {/* Corner accents */}
      <div className="absolute top-0 right-0 w-8 h-8 overflow-hidden">
        <div className="absolute top-0 right-0 w-px h-6 bg-gradient-to-b from-primary/50 to-transparent" />
        <div className="absolute top-0 right-0 h-px w-6 bg-gradient-to-l from-primary/50 to-transparent" />
      </div>
      <div className="absolute bottom-0 left-0 w-8 h-8 overflow-hidden">
        <div className="absolute bottom-0 left-0 w-px h-6 bg-gradient-to-t from-accent/30 to-transparent" />
        <div className="absolute bottom-0 left-0 h-px w-6 bg-gradient-to-r from-accent/30 to-transparent" />
      </div>
    </motion.div>
  );
}

export default function FeaturesSection({ featuresImage }) {
  return (
    <section id="features" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img src={featuresImage} alt="City" className="w-full h-full object-cover opacity-10" />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/98 to-background" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-xs font-bold tracking-widest text-accent mb-4 block">RECURSOS</span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-foreground">
            O QUE TE ESPERA NAS <span className="text-primary">RUAS</span>
          </h2>
          <div className="mt-6 flex items-center justify-center gap-3">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-primary" />
            <div className="w-2 h-2 rotate-45 bg-accent" />
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-primary" />
          </div>
        </motion.div>

        {/* Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map(({ icon, title, desc }, i) => (
            <FeatureCard key={title} icon={icon} title={title} desc={desc} i={i} />
          ))}
        </div>
      </div>
    </section>
  );
}