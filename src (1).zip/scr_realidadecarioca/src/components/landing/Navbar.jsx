import React, { useState, useEffect } from 'react';
import { Menu, X, Zap } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from 'framer-motion';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const links = [
    { label: 'INÍCIO', href: '#hero' },
    { label: 'FACÇÕES', href: '#factions' },
    { label: 'EVENTOS', href: '#events' },
    { label: 'COMO JOGAR', href: '#howtoplay' },
    { label: 'RANKING', href: '#ranking' },
    { label: 'DONOS', href: '#owners' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
      scrolled ? 'bg-background/90 backdrop-blur-xl border-b border-border' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <a href="#hero" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded bg-primary flex items-center justify-center">
            <Zap className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="text-lg font-extrabold tracking-wider text-foreground">
            NEW <span className="text-primary">RIO</span>
          </span>
        </a>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8">
          {links.map(link => (
            <a
              key={link.label}
              href={link.href}
              className="text-xs font-semibold tracking-widest text-muted-foreground hover:text-primary transition-colors duration-300"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* CTA */}
        <div className="hidden md:block">
          <Button
            size="sm"
            className="bg-primary hover:bg-primary/80 text-primary-foreground font-bold tracking-wider text-xs px-6"
            onClick={() => {
              navigator.clipboard.writeText('play.newrio.com:7777');
              document.getElementById('hero')?.scrollIntoView({ behavior: 'smooth' });
            }}
          >
            CONECTAR
          </Button>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-foreground" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="md:hidden bg-background/95 backdrop-blur-xl border-b border-border px-6 pb-6 pt-2"
          >
            {links.map(link => (
              <a
                key={link.label}
                href={link.href}
                className="block py-3 text-sm font-semibold tracking-widest text-muted-foreground hover:text-primary transition-colors"
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </a>
            ))}
            <Button
              className="w-full mt-4 bg-primary hover:bg-primary/80 text-primary-foreground font-bold tracking-wider text-xs"
              onClick={() => {
                navigator.clipboard.writeText('play.newrio.com:7777');
                setMobileOpen(false);
              }}
            >
              CONECTAR
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}