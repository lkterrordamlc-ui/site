import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Users, Flame, Heart, AlertTriangle, Handshake } from 'lucide-react';

const pillars = [
  {
    icon: MapPin,
    color: '#2D5BFF',
    title: 'TERRITÓRIOS REAIS',
    desc: 'Cada distrito do New Rio é inspirado em bairros reais do Rio de Janeiro — do Complexo do Alemão à Barra da Tijuca. A geografia é nossa, a guerra também.',
  },
  {
    icon: Users,
    color: '#FFB800',
    title: 'CULTURA DA QUEBRADA',
    desc: 'Gírias, costumes e a vibe única das comunidades cariocas vivem dentro do servidor. Aqui o funk toca, o baile rola e o respeito se conquista na marra.',
  },
  {
    icon: Flame,
    color: '#FF3E3E',
    title: 'SOBREVIVÊNCIA URBANA',
    desc: 'A vida na favela digital não é fácil. Você vai trabalhar, negociar, trair e ser traído. Só os mais espertos sobem na hierarquia.',
  },
  {
    icon: Heart,
    color: '#2D5BFF',
    title: 'COMUNIDADE UNIDA',
    desc: 'Apesar da rivalidade, nossa comunidade tem valores. Respeito ao próximo, ajuda ao novato e lealdade à facção são pilares do New Rio.',
  },
  {
    icon: AlertTriangle,
    color: '#FFB800',
    title: 'CONFLITO & TENSÃO',
    desc: 'Guerras de facções, roubos, perseguições e negociações — tudo inspirado na tensão real das ruas. Mas aqui é game, aqui é arte.',
  },
  {
    icon: Handshake,
    color: '#FF3E3E',
    title: 'DA FAVELA PRO MUNDO',
    desc: 'O New Rio orgulha-se das suas origens. Jogadores de todo o Brasil se unem para viver uma experiência que só quem é da quebrada entende.',
  },
];

export default function CommunitySection({ favelaBg }) {
  return (
    <section id="community" className="relative py-24 md:py-32 overflow-hidden">
      {/* BG */}
      <div className="absolute inset-0">
        <img src={favelaBg} alt="" className="w-full h-full object-cover opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/85 to-background" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-xs font-bold tracking-widest text-accent mb-4 block">O TEMA</span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-foreground leading-tight">
            A REALIDADE DAS<br />
            <span className="text-primary">COMUNIDADES CARIOCAS</span>
          </h2>
          <div className="mt-6 max-w-2xl mx-auto">
            <p className="text-sm text-muted-foreground leading-relaxed">
              O New Rio não se inspira em filmes americanos. Nosso DNA vem das favelas,
              dos bailes funk, das guerras de morro e da força da periferia brasileira.
              Um roleplay que respeita e celebra a cultura que veio de baixo.
            </p>
          </div>
        </motion.div>

        {/* Pillar grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {pillars.map(({ icon: Icon, color, title, desc }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              whileHover={{ y: -5, scale: 1.02 }}
              className="group relative p-5 rounded-xl bg-card/50 border border-border hover:border-white/10 transition-all duration-400 overflow-hidden cursor-default"
            >
              {/* Hover glow */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-xl"
                style={{ background: `radial-gradient(circle at 30% 30%, ${color}18 0%, transparent 70%)` }}
              />

              {/* Top micro-line */}
              <motion.div
                initial={{ scaleX: 0 }}
                whileHover={{ scaleX: 1 }}
                transition={{ duration: 0.35 }}
                className="absolute top-0 left-4 right-4 h-px origin-left"
                style={{ background: `linear-gradient(to right, ${color}, transparent)` }}
              />

              <div className="relative z-10 flex gap-4">
                <div
                  className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center mt-0.5"
                  style={{ backgroundColor: `${color}15` }}
                >
                  <Icon className="w-5 h-5" style={{ color }} />
                </div>
                <div>
                  <h3 className="text-xs font-extrabold tracking-wider text-foreground mb-1.5">{title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Manifesto strip */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="mt-14 overflow-hidden py-5 border-y border-border relative"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-background z-10 pointer-events-none" />
          <motion.div
            animate={{ x: ['0%', '-50%'] }}
            transition={{ duration: 22, repeat: Infinity, ease: 'linear' }}
            className="flex gap-12 whitespace-nowrap"
          >
            {[...Array(6)].map((_, i) => (
              <span key={i} className="text-[11px] font-extrabold tracking-[0.3em] text-muted-foreground/30 flex-shrink-0">
                NEW RIO SAMP &nbsp;·&nbsp; CULTURA CARIOCA &nbsp;·&nbsp; FAVELA DIGITAL &nbsp;·&nbsp; ROLEPLAY BRASILEIRO &nbsp;·&nbsp; DA QUEBRADA PRO MUNDO &nbsp;·&nbsp; SEMCLEO & MENOG
              </span>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}