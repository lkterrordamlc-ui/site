import React from 'react';
import { motion } from 'framer-motion';
import { Download, Settings, Wifi, Gamepad2, ChevronRight } from 'lucide-react';

const steps = [
  {
    n: '01',
    icon: Download,
    title: 'BAIXE O SA-MP',
    desc: 'Instale o GTA San Andreas e o cliente SA-MP 0.3.7. Ambos estão disponíveis gratuitamente. Siga o tutorial no nosso Discord.',
    color: '#2D5BFF',
    link: '#',
    linkLabel: 'TUTORIAL DE INSTALAÇÃO',
  },
  {
    n: '02',
    icon: Settings,
    title: 'CONFIGURE O CLIENTE',
    desc: 'Abra o SA-MP, vá em "Add Server" e adicione nosso IP. Coloque um nickname único — esse será seu nome nas ruas de New Rio.',
    color: '#FFB800',
    link: null,
    linkLabel: null,
  },
  {
    n: '03',
    icon: Wifi,
    title: 'CONECTE-SE',
    desc: 'IP: play.newrio.com:7777. Clique em conectar e aguarde o carregamento. Seja bem-vindo às ruas mais perigosas do Brasil.',
    color: '#FF3E3E',
    link: null,
    linkLabel: null,
  },
  {
    n: '04',
    icon: Gamepad2,
    title: 'ESCOLHA SUA VIDA',
    desc: 'Crie seu personagem, decida se será trabalhador honesto ou gangster. Leia as regras, respeite a comunidade e domine as ruas.',
    color: '#2D5BFF',
    link: '#',
    linkLabel: 'VER REGRAS',
  },
];

export default function HowToPlay() {
  return (
    <section id="howtoplay" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-card/20 via-background to-background" />
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: 'radial-gradient(circle, hsl(227 100% 59%) 1px, transparent 1px)',
        backgroundSize: '32px 32px',
      }} />

      <div className="relative z-10 max-w-6xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-xs font-bold tracking-widest text-accent mb-4 block">GUIA RÁPIDO</span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-foreground">
            COMO <span className="text-primary">COMEÇAR</span>
          </h2>
          <div className="mt-6 flex items-center justify-center gap-3">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-accent" />
            <div className="w-2 h-2 rotate-45 bg-primary" />
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-accent" />
          </div>
          <p className="mt-4 text-sm text-muted-foreground">Em menos de 5 minutos você estará jogando.</p>
        </motion.div>

        {/* Steps */}
        <div className="relative">
          {/* Connector line */}
          <div className="hidden md:block absolute top-9 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />

          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
            {steps.map(({ n, icon: Icon, title, desc, color, link, linkLabel }, i) => (
              <motion.div
                key={n}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                whileHover={{ y: -6 }}
                className="group relative flex flex-col items-center text-center"
              >
                {/* Circle */}
                <div className="relative mb-6 z-10">
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center border-2 transition-all duration-300 group-hover:scale-110"
                    style={{ borderColor: `${color}60`, backgroundColor: `${color}15` }}
                  >
                    <Icon className="w-6 h-6" style={{ color }} />
                  </div>
                  {/* Step number */}
                  <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-background border border-border flex items-center justify-center">
                    <span className="text-[8px] font-black text-foreground">{n.slice(1)}</span>
                  </div>
                  {/* Glow */}
                  <div
                    className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-40 transition-opacity duration-500 blur-lg"
                    style={{ backgroundColor: color }}
                  />
                </div>

                <h3 className="text-sm font-extrabold tracking-wider text-foreground mb-2">{title}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed mb-4">{desc}</p>

                {link && (
                  <a
                    href={link}
                    className="inline-flex items-center gap-1 text-[9px] font-extrabold tracking-widest transition-colors duration-200 hover:opacity-80"
                    style={{ color }}
                  >
                    {linkLabel} <ChevronRight className="w-3 h-3" />
                  </a>
                )}

                {/* Arrow between steps — mobile */}
                {i < steps.length - 1 && (
                  <div className="md:hidden mt-4">
                    <ChevronRight className="w-4 h-4 text-muted-foreground rotate-90 mx-auto" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>

        {/* CTA box */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="mt-16 p-8 rounded-2xl border border-primary/20 bg-primary/5 text-center relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-accent/5" />
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
          <div className="relative z-10">
            <p className="text-xl sm:text-2xl font-black tracking-tight text-foreground mb-2">
              PRONTO PARA AS RUAS?
            </p>
            <p className="text-sm text-muted-foreground mb-6">Conecte agora e comece sua história no New Rio.</p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => navigator.clipboard.writeText('play.newrio.com:7777')}
                className="px-8 py-3 rounded-xl bg-primary text-primary-foreground text-sm font-extrabold tracking-wider hover:bg-primary/80 transition-colors"
              >
                COPIAR IP DO SERVIDOR
              </motion.button>
              <span className="font-mono text-xs text-muted-foreground tracking-wider px-4 py-3 rounded-xl border border-border bg-card/50">
                play.newrio.com:7777
              </span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}