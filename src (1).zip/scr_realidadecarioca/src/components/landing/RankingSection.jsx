import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Crown, Skull, Flame, Star, ChevronUp, ChevronDown, Minus, Zap, Shield, Target } from 'lucide-react';

const players = [
  { rank: 1, name: 'VipeR_BR', level: 87, kills: 4821, deaths: 312, faction: 'Los Santos Cartel', score: 98420, trend: 'up', badge: 'crown' },
  { rank: 2, name: 'xX_Shadow_Xx', level: 82, kills: 4203, deaths: 289, faction: 'Vagos', score: 91780, trend: 'up', badge: 'flame' },
  { rank: 3, name: 'CrazyDriver99', level: 79, kills: 3987, deaths: 445, faction: 'Ballas', score: 87340, trend: 'same', badge: 'star' },
  { rank: 4, name: 'NightHawk', level: 75, kills: 3540, deaths: 380, faction: 'Grove Street', score: 79100, trend: 'up', badge: null },
  { rank: 5, name: 'TigreRio', level: 73, kills: 3321, deaths: 412, faction: 'Mafia', score: 73850, trend: 'down', badge: null },
  { rank: 6, name: 'Ghost_BR', level: 70, kills: 3102, deaths: 390, faction: 'SWAT', score: 68430, trend: 'up', badge: null },
  { rank: 7, name: 'FavelaDon', level: 68, kills: 2987, deaths: 501, faction: 'Vagos', score: 62100, trend: 'down', badge: null },
  { rank: 8, name: 'NeonRacer', level: 65, kills: 2801, deaths: 340, faction: 'Sem Facção', score: 58900, trend: 'up', badge: null },
  { rank: 9, name: 'UrbanWolf', level: 63, kills: 2654, deaths: 420, faction: 'Los Santos Cartel', score: 54200, trend: 'same', badge: null },
  { rank: 10, name: 'PhantomKid', level: 60, kills: 2490, deaths: 310, faction: 'Ballas', score: 49800, trend: 'down', badge: null },
];

const rankColors = {
  1: 'text-yellow-400',
  2: 'text-slate-300',
  3: 'text-amber-600',
};

const badgeIcons = {
  crown: { icon: Crown, color: 'text-yellow-400' },
  flame: { icon: Flame, color: 'text-orange-400' },
  star: { icon: Star, color: 'text-amber-500' },
};

const trendIcon = {
  up: <ChevronUp className="w-3 h-3 text-green-400" />,
  down: <ChevronDown className="w-3 h-3 text-red-400" />,
  same: <Minus className="w-3 h-3 text-muted-foreground" />,
};

function PlayerRow({ player, i }) {
  const [hovered, setHovered] = useState(false);
  const BadgeIcon = player.badge ? badgeIcons[player.badge].icon : null;

  return (
    <motion.div
      initial={{ opacity: 0, x: -30 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ delay: i * 0.06, duration: 0.4 }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="relative group cursor-pointer"
    >
      {/* Glow line on hover */}
      <AnimatePresence>
        {hovered && (
          <motion.div
            initial={{ scaleX: 0, opacity: 0 }}
            animate={{ scaleX: 1, opacity: 1 }}
            exit={{ scaleX: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="absolute left-0 top-0 bottom-0 w-0.5 bg-primary origin-top"
          />
        )}
      </AnimatePresence>

      <motion.div
        animate={{ x: hovered ? 4 : 0 }}
        transition={{ duration: 0.2 }}
        className={`flex items-center gap-3 sm:gap-5 px-4 sm:px-6 py-4 rounded-xl border transition-all duration-300 ${
          player.rank <= 3
            ? 'bg-card border-primary/20 hover:border-primary/50'
            : 'bg-card/40 border-border hover:border-border/80 hover:bg-card/70'
        }`}
      >
        {/* Rank */}
        <div className="w-8 flex-shrink-0 text-center">
          {player.rank <= 3 ? (
            <span className={`text-lg font-black ${rankColors[player.rank]}`}>#{player.rank}</span>
          ) : (
            <span className="text-sm font-bold text-muted-foreground">#{player.rank}</span>
          )}
        </div>

        {/* Avatar */}
        <div className={`relative w-9 h-9 flex-shrink-0 rounded-lg flex items-center justify-center font-extrabold text-sm ${
          player.rank === 1 ? 'bg-yellow-400/10 text-yellow-400' :
          player.rank === 2 ? 'bg-slate-300/10 text-slate-300' :
          player.rank === 3 ? 'bg-amber-600/10 text-amber-500' :
          'bg-primary/10 text-primary'
        }`}>
          {player.name.slice(0, 2).toUpperCase()}
          {BadgeIcon && (
            <div className="absolute -top-1.5 -right-1.5">
              <BadgeIcon className={`w-3.5 h-3.5 ${badgeIcons[player.badge].color}`} />
            </div>
          )}
        </div>

        {/* Name + Faction */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className={`text-sm font-bold truncate ${player.rank <= 3 ? 'text-foreground' : 'text-foreground/80 group-hover:text-foreground transition-colors'}`}>
              {player.name}
            </p>
            {trendIcon[player.trend]}
          </div>
          <p className="text-[10px] text-muted-foreground tracking-wider truncate">{player.faction}</p>
        </div>

        {/* Stats — hidden on very small screens */}
        <div className="hidden sm:flex items-center gap-6 flex-shrink-0">
          <div className="text-center">
            <p className="text-xs font-bold text-foreground">{player.kills.toLocaleString()}</p>
            <p className="text-[9px] tracking-widest text-muted-foreground">KILLS</p>
          </div>
          <div className="text-center">
            <p className="text-xs font-bold text-muted-foreground">{player.deaths.toLocaleString()}</p>
            <p className="text-[9px] tracking-widest text-muted-foreground">MORTES</p>
          </div>
          <div className="text-center">
            <p className="text-xs font-bold text-foreground">LV {player.level}</p>
            <p className="text-[9px] tracking-widest text-muted-foreground">NÍVEL</p>
          </div>
        </div>

        {/* Score */}
        <div className="flex-shrink-0 text-right">
          <p className={`text-sm font-black tabular-nums ${player.rank <= 3 ? 'text-primary' : 'text-foreground/60 group-hover:text-primary/80 transition-colors'}`}>
            {player.score.toLocaleString()}
          </p>
          <p className="text-[9px] tracking-widest text-muted-foreground">PONTOS</p>
        </div>
      </motion.div>
    </motion.div>
  );
}

const tabs = ['GERAL', 'KILLS', 'NÍVEL'];

export default function RankingSection() {
  const [activeTab, setActiveTab] = useState(0);

  const sorted = [...players].sort((a, b) => {
    if (activeTab === 1) return b.kills - a.kills;
    if (activeTab === 2) return b.level - a.level;
    return a.rank - b.rank;
  });

  return (
    <section id="ranking" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-card/20 to-background" />
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: 'radial-gradient(hsl(227 100% 59%) 1px, transparent 1px)',
        backgroundSize: '40px 40px',
      }} />

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <span className="text-xs font-bold tracking-widest text-primary mb-4 block">HALL DA FAMA</span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-foreground">
            TOP <span className="text-primary">JOGADORES</span>
          </h2>
          <div className="mt-6 flex items-center justify-center gap-3">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-accent" />
            <div className="w-2 h-2 rotate-45 bg-primary" />
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-accent" />
          </div>
          <p className="mt-4 text-xs text-muted-foreground tracking-widest">
            ATUALIZADO EM TEMPO REAL · NEW RIO SAMP
          </p>
        </motion.div>

        {/* Tab selector */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-center justify-center gap-2 mb-8"
        >
          {tabs.map((tab, i) => (
            <button
              key={tab}
              onClick={() => setActiveTab(i)}
              className={`relative px-5 py-2 text-xs font-extrabold tracking-widest rounded-lg transition-all duration-300 ${
                activeTab === i
                  ? 'text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {activeTab === i && (
                <motion.div
                  layoutId="tab-bg"
                  className="absolute inset-0 bg-primary rounded-lg"
                />
              )}
              <span className="relative z-10">{tab}</span>
            </button>
          ))}
        </motion.div>

        {/* Column headers */}
        <div className="hidden sm:flex items-center gap-3 sm:gap-5 px-6 mb-3 text-[9px] font-bold tracking-widest text-muted-foreground">
          <div className="w-8 text-center">POS</div>
          <div className="w-9" />
          <div className="flex-1">JOGADOR</div>
          <div className="flex gap-6 mr-0">
            <span className="w-12 text-center">KILLS</span>
            <span className="w-12 text-center">MORTES</span>
            <span className="w-10 text-center">NÍVEL</span>
          </div>
          <div className="w-16 text-right flex-shrink-0">PONTOS</div>
        </div>

        {/* Players list */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="space-y-2"
          >
            {sorted.map((player, i) => (
              <PlayerRow key={player.name} player={player} i={i} />
            ))}
          </motion.div>
        </AnimatePresence>

        {/* Bottom promo */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-10 p-5 rounded-xl border border-primary/20 bg-primary/5 flex flex-col sm:flex-row items-center justify-between gap-4"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
              <Target className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-sm font-extrabold text-foreground tracking-wide">QUER ESTAR AQUI?</p>
              <p className="text-xs text-muted-foreground">Conecte-se agora e comece sua jornada</p>
            </div>
          </div>
          <button
            onClick={() => { navigator.clipboard.writeText('play.newrio.com:7777'); }}
            className="group flex items-center gap-2 px-6 py-2.5 rounded-lg bg-primary hover:bg-primary/80 text-primary-foreground text-xs font-extrabold tracking-widest transition-all duration-300"
          >
            <Zap className="w-3.5 h-3.5 group-hover:scale-125 transition-transform" />
            JOGAR AGORA
          </button>
        </motion.div>
      </div>
    </section>
  );
}